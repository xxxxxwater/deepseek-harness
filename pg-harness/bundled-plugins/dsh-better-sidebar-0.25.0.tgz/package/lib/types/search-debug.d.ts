/** Append one debug line (gated; no-op unless DSH_SEARCH_DEBUG=1). */
export declare function debugLog(msg: string): void;
