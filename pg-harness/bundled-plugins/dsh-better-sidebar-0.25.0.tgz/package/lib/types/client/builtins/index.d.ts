/**
 * Built-in registration: the plugin registers its own tab pages and file
 * previewers through the same {@link BetterSidebarService} external plugins
 * use — eating its own dogfood. The descriptors live next to their feature
 * modules (tabs.tsx / viewers.tsx); this module only aggregates them and
 * owns the disposer lifecycle (cordis auto-invokes it on fiber disposal,
 * HMR-safe).
 */
import type { Context } from '../../context-types.ts';
import type { BetterSidebarService } from '../service.ts';
/**
 * Register all built-in tabs and viewers with the service. Returns a
 * disposer that unregisters everything (cordis auto-invokes it on fiber
 * disposal). The `ctx` is threaded into the descriptor factory that needs it
 * (the bottom terminal's `onClose` probes `ctx.webTerminals` to end the host
 * process; components read `ctx.betterSidebar` from their props).
 */
export declare function registerBuiltins(ctx: Context, service: BetterSidebarService): () => void;
