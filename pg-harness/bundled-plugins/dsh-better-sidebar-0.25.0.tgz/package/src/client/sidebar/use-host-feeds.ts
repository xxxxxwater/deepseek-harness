/**
 * Host-feed subscriptions (extracted from Sidebar.tsx, behavior identical):
 * the WebSocket push (agent opens) and the session-list / job-list driven
 * auto-activation triggers (subagent, background jobs, topology
 * jump-back). All of it reacts to the host's live feeds for the CURRENT
 * session; the sidebar shell only consumes the returned jump-back ref.
 */
import { useEffect, useRef } from 'react'
import type { Context, SidebarJobView, SidebarSessionList } from '../../context-types.ts'
import type { SidebarStore } from '../state.ts'
import { isNarrowWidth } from '../breakpoints.ts'
import { hostWebSocketUrl } from '../host-route-url.ts'
import { detectNewDirectSubagent } from '../subagent-detect.ts'
import { detectNewJob } from '../subagent-jobs.ts'
import { clientJobs, useJobsSnapshot } from '../jobs-client.ts'
import { mountedSessionId } from '../native/surface.ts'
import { t } from '../locales.ts'

/** How many consecutive reconnect failures stop the agent-opens push loop
 * (the loop restarts on session switch). */
const FAILURE_LIMIT = 3

/**
 * Subagent auto-open debounce (ms). The host delivers a new child's origin
 * and its title in SEPARATE frames: a Side Chat thread's first visible
 * frame still shows a fallback title (no 'Side: ' prefix), so an immediate
 * 0→N decision mistakes it for a genuine subagent and pops the task page.
 * The trigger therefore re-evaluates against the live snapshot once the
 * title frame has had time to land.
 */
const AUTO_OPEN_DEBOUNCE_MS = 500

/**
 * The native column's public face, as this module reaches it. Every reader
 * acts on the session whose surface is MOUNTED (the controller reads its
 * binding), which is why both gates below are gated on the target session
 * being the on-screen one.
 */
interface NativeColumnFace {
  isExpanded?: () => boolean
  toggleExpanded?: () => void
  /** The active tab of the active pane (`ISidebarRight.active`): which page the
   *  reader is looking at. Absent on a host older than the reader gate. */
  active?: () => { kind?: string } | undefined
}

/**
 * Activate the Tasks page (the `subagent` tab type) in DSH's native right
 * Sidebar — the landing the two auto-open switches promise: the right column
 * IS the sidebar the user means, while the plugin's own bottom workbench only
 * serves its own flows (its `+` menu and the first-expansion terminal). Every
 * other open in this plugin already lands there, so a `target: 'bottom'` here
 * puts the Tasks page in the bottom bar instead.
 *
 * A background activation must not take over a narrow viewport: below 768px
 * the host draws that column FULLSCREEN, so the tab is placed and the column
 * is put back to collapsed — parked, waiting behind the expand control,
 * instead of covering the chat. The host expands on every open
 * (`openContent` plans `setExpanded(true)`) and offers no option to suppress
 * it, hence the read-then-restore pair: both commits land in one React batch,
 * so the column never renders the intermediate state. The viewport is read
 * when the activation FIRES (the debounced subagent trigger included), so a
 * resize while arming is honoured.
 *
 * A background activation must not replace the page the reader is on either,
 * on ANY viewport: the host's open focuses what it opens, so "activate" means
 * "take the column over", and doing that while the reader is in a document
 * (a file, a diff, a side chat) throws their page out of view on every new
 * subagent / background job — the one thing a DELAYED trigger may never do.
 * The gate is the wide-viewport twin of the park below and asks the same
 * question — is the column in use? — of the same session: a COLLAPSED column
 * shows nothing, so its tabs may be re-pointed freely (that is where the two
 * switches still land, and where the narrow park keeps them), while an
 * EXPANDED one showing a page other than the Tasks page is in use and is left
 * alone. A column already on the Tasks page is re-focused in place as before
 * (single-instance semantics make it a no-op).
 *
 * Leaving it at that would DROP the event: the page the background work
 * belongs to must still be created, it just may not take the column over.
 * So a gated activation opens the same page with `reveal: false` — the host
 * places the tab without focusing it (`openContent`'s `revealIfOpened: false`
 * suppresses exactly the focus op; the page kind has no focus path of its own,
 * and re-opening a page that IS already there is a focus either way, which is
 * precisely what the gate refuses) — and marks the tab type unread, which is
 * the dot the reader follows to it later. The two halves are one change:
 * without the dot the tab would be created invisibly, and without the open
 * there would be nothing for the dot to point at.
 *
 * @param ctx - the client context (`ctx.sidebarRight` + `ctx.betterSidebar`).
 * @param store - the plugin store (the unread dot lives in the session state).
 * @param sessionId - the session the feed reports the activity for.
 * @param options.background - `true` for background activity (refuses a
 *   column the reader is using, parks on narrow viewports); `false` for the
 *   explicit topology jump-back, which is a user gesture and always leaves the
 *   column as the host expanded it.
 */
function activateTasksPage(
  ctx: Context,
  store: SidebarStore,
  sessionId: string,
  options: { background: boolean },
): void {
  const column = ctx.get('sidebarRight') as unknown as NativeColumnFace | undefined
  // The face acts on the MOUNTED session: both gates below are only meaningful
  // (and only safe) when the activation targets the one on screen. "On screen"
  // is the native surface's own mounted seat — the session list has no
  // current-session field — and an absent seat (a global panel, or a host
  // without the feed) reads as "not this session": the plugin then leaves the
  // column alone rather than reading or toggling one it is not drawing.
  const onScreen = mountedSessionId(ctx) === sessionId
  // Do not take over the page the reader is looking at (see the docblock).
  if (options.background && onScreen && column?.isExpanded?.() === true) {
    const shown = column.active?.()
    if (shown !== undefined && shown.kind !== 'subagent') {
      // The page is still created — the event is never dropped — but it lands
      // in the background and raises the dot instead of the column.
      ctx.get('betterSidebar')?.openTab({ type: 'subagent', title: t('subagent'), reveal: false })
      // The dot belongs to the session the work is in, which is the current
      // one (the gate above proved this seat is the mounted session).
      store.markUnread('subagent')
      return
    }
  }
  const park = options.background
    && onScreen
    && isNarrowWidth(window.innerWidth)
    // Only a column the user had COLLAPSED is put back: an expanded one is in
    // use, and closing it under the user would be worse than the takeover.
    && column?.isExpanded?.() === false
  ctx.get('betterSidebar')?.openTab({ type: 'subagent', title: t('subagent') })
  if (park) column?.toggleExpanded?.()
}

export function useHostFeeds(feeds: {
  ctx: Context
  store: SidebarStore
  sessionList: SidebarSessionList
  sessionId: string | undefined
}): { subagentJumpRef: { current: string | undefined } } {
  const { ctx, store, sessionList, sessionId } = feeds

  /**
   * Agent opens push: subscribe to the host's `sidebar_open` requests for
   * this session (the model actively opens a file / folder / HTTP(S) page).
   * The host pushes one JSON request per open; the sidebar routes it to the
   * matching built-in tab: a file opens in the editor (per-path dedupe), a
   * folder opens a file window whose tree is rooted at the folder
   * (`meta.dir`), and a URL opens in DSH's own browser tab type. A disconnected socket
   * retries with a short backoff (mirror of the agent-terminals loop): the
   * host queue keeps undelivered requests and replays them on the first
   * attach, so a refresh or a session switch lands the opens the model
   * queued while no view was connected.
   * While the side-card setting is off, pushes are ignored as a defensive
   * gate — the host already unregisters the tool and drains the queue.
   */
  useEffect(() => {
    if (sessionId === undefined) return
    let socket: WebSocket | null = null
    let retry: number | undefined
    let closed = false
    let failures = 0
    const connect = (): void => {
      if (closed) return
      const url = hostWebSocketUrl('sidebar/ws/agent-opens')
      url.search = new URLSearchParams({ sessionId }).toString()
      socket = new WebSocket(url.toString())
      socket.onmessage = (event) => {
        if (typeof event.data !== 'string') return
        try {
          const request = JSON.parse(event.data) as { kind?: unknown; target?: unknown; title?: unknown }
          if (request === null || typeof request !== 'object') return
          if (request.kind !== 'file' && request.kind !== 'folder' && request.kind !== 'url') return
          if (typeof request.target !== 'string' || request.target === '') return
          if (store.getPrefs().agentOpenTools !== true) return
          const scope = { sessionId }
          const title = typeof request.title === 'string' && request.title !== '' ? request.title : undefined
          if (request.kind === 'url') {
            // DSH's own browser tab type (absent from the plugin's registry
            // since 0.20.0); an unregistered kind throws, so the agent-open
            // path degrades to doing nothing rather than breaking the push.
            try {
              ctx.get('sidebarRight')?.openTab('browser', { params: { url: request.target } })
            } catch {
              // Host without a browser tab type: nothing to open into.
            }
          } else if (request.kind === 'folder') {
            ctx.get('betterSidebar')?.openTab({
              type: 'editor',
              title,
              path: request.target,
              id: `editor:${request.target}`,
              meta: { dir: true },
            }, scope)
          } else {
            ctx.get('betterSidebar')?.openFile(scope, request.target, title)
          }
        } catch {
          // Malformed push: ignore (the next push carries its own request).
        }
      }
      socket.onclose = () => {
        if (closed) return
        failures += 1
        if (failures >= FAILURE_LIMIT) {
          console.error('[dsh-better-sidebar] agent-opens connection failed; stopping reconnect loop', sessionId)
          return
        }
        retry = window.setTimeout(connect, 2000)
      }
      socket.onerror = () => { socket?.close() }
    }
    connect()
    return () => {
      closed = true
      window.clearTimeout(retry)
      socket?.close()
    }
  }, [sessionId, ctx, store])

  /**
   * Subagent auto-activation: the moment the current conversation spawns its
   * FIRST direct subagent (a 0 → N transition on the list feed), the "auto
   * open" pref is on, and the Tasks tab type is enabled in settings, activate
   * the Tasks page in DSH's native right Sidebar. Single-instance semantics
   * focus an existing tab in place; a new tab lands in that column and is
   * never duplicated. Landing it EXPANDS the column on wide viewports, while
   * a narrow viewport (where the host draws that column fullscreen) parks the
   * tab instead of taking the screen over — see {@link activateTasksPage},
   * which also refuses a column the reader has expanded onto another page.
   * Switching to a session that already has subagents never triggers — its
   * baseline starts at the current count — so a deliberate layout is never
   * fought.
   *
   * MOBILE: while the viewport is narrow (the plugin's own bracket), the
   * `mobileNoAutoOpen` preference suppresses this takeover entirely — on a
   * phone the Tasks page costs the whole screen, and the reader has not asked
   * for it. The viewport is read when the trigger FIRES, like the park gate.
   *
   * The decision is DEBOUNCED (AUTO_OPEN_DEBOUNCE_MS): a Side Chat thread
   * is also a subagent-origin child, and its 'Side: ' title lands one frame
   * after its origin — an immediate check would misread that first frame as
   * a new subagent and pop this page on every thread creation. The timer
   * re-evaluates the ORIGINAL baseline against the live snapshot; by then
   * the title filter (isSideThreadSummary) sees the settled label.
   */
  const listBaselineRef = useRef<SidebarSessionList | undefined>(undefined)
  const autoOpenPendingRef = useRef<{ baseline: SidebarSessionList; timer: number } | null>(null)
  useEffect(() => {
    const prev = listBaselineRef.current
    listBaselineRef.current = sessionList
    if (sessionId === undefined || prev === undefined) return
    if (autoOpenPendingRef.current !== null) return
    if (!detectNewDirectSubagent(prev, sessionList, sessionId)) return
    const baseline = prev
    const timer = window.setTimeout(() => {
      autoOpenPendingRef.current = null
      if (!detectNewDirectSubagent(baseline, ctx.sessions.list.getSnapshot(), sessionId)) return
      if (!store.getPrefs().autoOpenSubagent) return
      if (store.getPrefs().mobileNoAutoOpen && isNarrowWidth(window.innerWidth)) return
      if (ctx.get('betterSidebar')?.isTabEnabled('subagent') === false) return
      activateTasksPage(ctx, store, sessionId, { background: true })
    }, AUTO_OPEN_DEBOUNCE_MS)
    autoOpenPendingRef.current = { baseline, timer }
  }, [sessionList, sessionId, store, ctx])

  // A session switch (or unmount) voids any armed auto-open recheck.
  useEffect(() => () => {
    const pending = autoOpenPendingRef.current
    if (pending !== null) window.clearTimeout(pending.timer)
    autoOpenPendingRef.current = null
  }, [sessionId])

  /**
   * Job auto-activation: the moment a NEW background job appears for the
   * current conversation (a job id the previous read of its list lacked), the
   * auto-open pref is on, and the Tasks tab type is enabled, activate the Tasks
   * page that contains the background-jobs section — in DSH's native right
   * Sidebar, expanded on wide viewports and parked on narrow ones exactly like
   * the subagent trigger ({@link activateTasksPage}, which leaves a column the
   * reader has expanded onto another page untouched). Unlike that trigger
   * (0 → N only), ANY new job id triggers: the agent may start several jobs in
   * one session, and each should surface.
   *
   * MOBILE: `mobileNoAutoOpen` suppresses this one too on a narrow viewport
   * (one switch for both triggers — a phone should not be taken over by either
   * kind of background work).
   *
   * The roster is PUSHED by the host's own client jobs service: one
   * reference-counted `watchRows` stream for the current session replaces the
   * 3s `jobs.list` poll this used to run. A fresh page load never triggers —
   * the FIRST frame only arms the baseline — and a deployment without the
   * jobs service leaves the baseline unarmed, so the first roster that does
   * arrive is never mistaken for new work.
   *
   * `detectNewJob` also compares against the moment the watch STARTED: the
   * first frame of a session that already had running jobs must not surface
   * them as new work.
   */
  const jobsService = clientJobs(ctx)
  const jobsSnapshot = useJobsSnapshot(jobsService)
  const jobBaselineRef = useRef<readonly SidebarJobView[] | undefined>(undefined)
  const jobWatchStartRef = useRef<number | undefined>(undefined)
  useEffect(() => {
    if (jobsService === undefined || sessionId === undefined) return
    const release = jobsService.watchRows(sessionId)
    // A session switch voids the previous session's baseline AND its clock.
    jobWatchStartRef.current = Date.now()
    jobBaselineRef.current = undefined
    return () => {
      release()
      jobBaselineRef.current = undefined
      jobWatchStartRef.current = undefined
    }
  }, [jobsService, sessionId])
  useEffect(() => {
    if (jobsService === undefined || sessionId === undefined) return
    const rows = jobsSnapshot.rows[sessionId] ?? []
    const prev = jobBaselineRef.current
    jobBaselineRef.current = rows
    if (prev === undefined) return
    if (!detectNewJob(prev, rows, jobWatchStartRef.current)) return
    if (!store.getPrefs().autoOpenJobs) return
    if (store.getPrefs().mobileNoAutoOpen && isNarrowWidth(window.innerWidth)) return
    if (ctx.get('betterSidebar')?.isTabEnabled('subagent') === false) return
    activateTasksPage(ctx, store, sessionId, { background: true })
  }, [jobsService, jobsSnapshot, sessionId, store, ctx])

  /**
   * Topology jump-back: clicking a subagent node on the Subagent page calls
   * the official `openSubagent`, which switches the sidebar to that child
   * session's OWN layout (a fresh child session defaults to the explorer).
   * The README contract says the Subagent page must stay open with the jumped
   * node highlighted — so once the current session becomes the recorded jump
   * target, re-open the Tasks page on top of the child's layout, in DSH's
   * native right Sidebar. This one is an explicit user gesture, so it always
   * takes the host's expansion (no narrow-viewport parking). Only this node
   * click arms the flag, so switching to a subagent session by any other means
   * keeps that session's own layout untouched.
   */
  const subagentJumpRef = useRef<string | undefined>(undefined)
  useEffect(() => {
    const pending = subagentJumpRef.current
    if (pending === undefined || sessionId !== pending) return
    subagentJumpRef.current = undefined
    activateTasksPage(ctx, store, sessionId, { background: false })
  }, [sessionId, store, ctx])

  return { subagentJumpRef }
}
