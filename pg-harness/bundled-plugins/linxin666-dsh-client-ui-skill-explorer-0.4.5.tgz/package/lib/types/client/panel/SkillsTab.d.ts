import { SkillApi, type SkillEntry } from '../api.ts';
/** The skills tab body. */
export declare function SkillsTab({ api, onEdit }: {
    api: SkillApi;
    onEdit: (skill: SkillEntry) => void;
}): React.JSX.Element;
