import { SkillApi } from '../api.ts';
/** The create tab body. */
export declare function CreateTab({ api }: {
    api: SkillApi;
}): React.JSX.Element;
