/**
 * Skill center API client (browser half). Talks to the host route family over
 * same-origin fetch; the host enforces the trust fence on its side.
 */
/** One skill entry as served by the host. */
export interface SkillEntry {
    name: string;
    description: string;
    whenToUse?: string;
    provider?: string;
    level: string;
    path?: string;
    /** True for skills discovered through a symlink entry (deletion not allowed). */
    linked?: boolean;
    modelInvocable: boolean;
    userInvocable: boolean;
    /** Project workspace root path this skill belongs to. */
    workspaceRoot?: string;
    /** Display name of the workspace directory. */
    workspaceName?: string;
    /** True when the skill belongs to the primary active session workspace. */
    isActiveWorkspace?: boolean;
}
/** Group payload served by the host. */
export interface GroupPayload {
    key: string;
    title: string;
    hint: string;
    skills: SkillEntry[];
}
/** Workspace item descriptor. */
export interface WorkspaceItem {
    root: string;
    name: string;
    active: boolean;
}
/** List payload served by the host. */
export interface ListPayload {
    cwd: string;
    projectRoots: string[];
    complete: boolean;
    groups: GroupPayload[];
    workspaces?: WorkspaceItem[];
}
/** One thrown API error with the host-provided message. */
export declare class ApiError extends Error {
}
/** Skill center API client. */
export declare class SkillApi {
    /** Fetch the grouped skill list. */
    list(cwd?: string): Promise<ListPayload>;
    /** Enable or disable a skill (rewrites disable-model-invocation). */
    setEnabled(name: string, path: string, enabled: boolean): Promise<{
        name: string;
        enabled: boolean;
        modelInvocable: boolean;
        path?: string;
    }>;
    /** Create a skill file under the user or project root. */
    create(payload: {
        root: 'user' | 'project';
        name: string;
        description: string;
        whenToUse?: string;
        content: string;
        cwd: string;
    }): Promise<{
        ok: true;
        name: string;
        path: string;
    }>;
    /** One skill's editable fields and body, resolved from the panel's path. */
    read(name: string, path: string): Promise<{
        name: string;
        path: string;
        description: string;
        whenToUse?: string;
        content: string;
    }>;
    /** Rewrite an existing skill file in place (name and location unchanged). */
    update(payload: {
        name: string;
        path: string;
        description: string;
        whenToUse?: string;
        content: string;
    }): Promise<{
        ok: true;
        name: string;
        path: string;
        disabled: boolean;
    }>;
    /** Delete a skill (moves it into .trash). */
    remove(name: string, path: string): Promise<{
        ok: true;
        name: string;
        moved: string;
    }>;
    private request;
}
