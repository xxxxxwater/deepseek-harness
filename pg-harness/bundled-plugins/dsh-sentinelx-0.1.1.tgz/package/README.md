# dsh-sentinelx

SentinelX bridge for DeepSeek Harness. It connects the harness to a
[SentinelX](https://sentinelx.app) hub over MCP using OAuth 2.0 — dynamic client
registration, authorization code with PKCE, and a loopback redirect — and
registers the hub's tools on the session as if they were native.

Tools appear under the same names Codex and Claude Code use:

```
mcp__sentinelx__sentinel_exec
mcp__sentinelx__sentinel_service
mcp__sentinelx__sentinel_edit
...
```

This is the harness-side counterpart of the Codex "SentinelX" app: Codex talks
to a connector hosted by OpenAI, which a third-party client cannot reuse. This
package signs in directly, against the same hub, with its own OAuth client.

## What you need

1. A SentinelX account with at least one host enrolled.
2. The SentinelX agent installed on that host. On a Linux VPS with systemd:

   ```bash
   curl -fsSL https://get.sentinelx.app | bash
   ```

   The installer registers a service, writes `/etc/sentinelx/config.yaml`, and
   opens a browser sign-in. The host then appears in your account at
   <https://mcp.sentinelx.app/dashboard>.

   The agent only runs what that config allows: `allowed_commands`,
   `services`, and `file_ops.paths` are deny-by-default allowlists. Nothing this
   plugin (or the model) can do widens them.

3. The plugin then connects to the hub endpoint
   `https://mcp.sentinelx.app/mcp/mcp`.

## Install

**From the Plugins page** — open the sidebar **Plugins** page, choose
**Add plugin**, and enter the package name or the path to this directory.
The bundle patches itself in; no profile files need editing.

**From the CLI** — quit the app first, then:

```bash
"/Applications/DeepSeek Harness.app/Contents/Resources/runtime/cli/bin/dsh" \
  plugin --profile desktop add /Users/christse/Desktop/dsh-sentinelx
```

The `desktop` profile is managed by the Electron app, so the app's own CLI shim
is the supported way to add to it; the standalone `dsh` refuses that profile by
name.

## Sign in

The harness must boot before it can sign in, so the plugin always registers one
self-owned tool even when it is not connected:

```
mcp__sentinelx__sentinel_auth
```

Ask for status, or sign in from a shell instead (this works before the harness
starts):

```bash
dsh-sentinelx login      # opens the browser, stores tokens, prints the tool list
dsh-sentinelx status     # show the stored client, issuer, token lifetime
dsh-sentinelx tools      # connect with stored credentials and list tools
dsh-sentinelx logout     # delete stored credentials
```

Credentials live in `$DSH_HOME/sentinelx/oauth.json` (mode `0600`) and hold the
registered `client_id`, the access and refresh tokens, and the PKCE verifier.
Access tokens refresh silently; you should only sign in once.

`mcp__sentinelx__sentinel_auth` accepts `action`: `status` (default), `login`,
`refresh`, or `logout`.

## Configuration

Set these on the bundle's row in the profile, or on the inserted row in
`cordis.patch.yml`:

| Field | Default | Meaning |
|---|---|---|
| `url` | `https://mcp.sentinelx.app/mcp/mcp` | Hub MCP endpoint |
| `serverName` | `sentinelx` | Tool namespace: `mcp__<serverName>__<tool>` |
| `statePath` | `$DSH_HOME/sentinelx/oauth.json` | Credentials file |
| `scopes` | OIDC + every `sentinelx:*` scope | Scope request |
| `redirectPort` | `33418` | Loopback redirect port; keep it fixed |
| `protocolEra` | `legacy` | MCP era negotiation; `auto` adds a probe this hub does not answer |
| `callbackPath` | `/callback` | Loopback callback path |
| `toolCallTimeoutMs` | `60000` | Per-call timeout |
| `authorizationTimeoutMs` | `300000` | How long a sign-in may wait |
| `interactiveAuth` | `true` | Allow a browser sign-in at all |
| `openBrowser` | `true` | Launch a browser instead of only logging the URL |
| `failOnStartupError` | `false` | Reject plugin activation when the hub is unreachable |
| `staticToken` | — | Skip OAuth and present a fixed bearer token |

Keeping `redirectPort` fixed matters: the hub binds the redirect URI at
registration time, so an ephemeral port would force a fresh registration every
restart. `staticToken` exists for a self-hosted deployment that issues tokens
itself.

## Behavior worth knowing

- **The harness still starts when the hub is unreachable or unauthorized.** The
  connection tool stays registered so a turn can sign in or retry. Set
  `failOnStartupError: true` for the opposite behavior.
- **Server instructions are injected** as a system-prompt section, so the model
  learns the host's allowlist before calling anything.
- **A failed tool refresh leaves the previous tool generation in place**; the
  same fetch-then-swap ordering the harness MCP bridge uses.
- **Tool names are stable** across restarts, so permission rules and session
  history keep working.

## Security notes

- The trust boundary is the **host's allowlist**, not this plugin. The agent
  rejects anything outside `/etc/sentinelx/config.yaml` regardless of what the
  model asks for.
- Stored credentials are owner-readable only. `logout` deletes them; there is no
  remote revocation call, so also remove the client under your identity
  provider if you need that.
- A sign-in opens a loopback listener on `redirectPort` and validates the
  returned `state` value; a callback that does not carry the expected `state` is
  rejected and never redeemed.

## Rollback

```bash
dsh-sentinelx logout
"/Applications/DeepSeek Harness.app/Contents/Resources/runtime/cli/bin/dsh" \
  plugin --profile desktop remove dsh-sentinelx
```

Then remove the `sentinelx` row if the profile's `cordis.patch.yml` still lists
it. Nothing outside the DSH home and the app's profile directory is touched.

## Tests

```bash
npm test
```

The suite runs entirely offline against a mock hub that implements protected
resource metadata, authorization-server metadata, dynamic client registration,
PKCE S256 verification, the authorization redirect, token issue and refresh, and
a Streamable HTTP MCP endpoint that rejects unauthenticated and expired tokens.
It covers the provider contract, the full sign-in flow, token reuse and refresh,
`state` mismatch rejection, plugin composition, startup failure modes, and the
packaged CLI as a subprocess.

## Known limitations

- **Dynamic client registration is deprecated** in MCP protocol revision
  2026-07-28 in favour of Client ID Metadata Documents. The hub currently
  advertises a `registration_endpoint` and no CIMD support, so this plugin uses
  DCR; the SDK switches to CIMD automatically if the hub adopts it and
  `clientMetadataUrl` is configured.
- **No dedicated step-up prompt**: a `403 insufficient_scope` is handled by the
  SDK's default reauthorize path, which can open a browser mid-turn.
- **One hub per plugin row.** A second SentinelX deployment needs a second
  profile row with a distinct `serverName`.
- **Image-bearing tool results** are projected only when the active model
  declares image input; otherwise the harness returns the text fallback that the
  shared MCP adapter produces.
