/**
 * End-to-end smoke test for the dsh-magicpath bridge.
 *
 * Runs the real MagicPath CLI through the same code path the model-callable
 * tool uses, and prints the canonical value the tool would have returned.
 *
 *   node scripts/smoke.mjs [command] [args...]
 *
 * Defaults to `info`. Requires network access on the first run, because the
 * CLI is fetched through npx unless it is installed locally.
 */

import { buildArgv, runMagicPath } from '../lib/cli.js'
import { toCanonical } from '../lib/index.js'

const [command = 'info', ...args] = process.argv.slice(2)
const argv = buildArgv({ command, args })
const started = Date.now()
const outcome = await runMagicPath({ argv, timeoutMs: 120_000 })
const value = toCanonical(command, argv, outcome, { cacheDir: outcome.cacheDir })

console.log(JSON.stringify({
  argv,
  transport: outcome.usedNpx ? 'npx' : 'local',
  cacheDir: outcome.cacheDir,
  ms: Date.now() - started,
  ...value,
}, null, 2))
process.exitCode = value.ok ? 0 : 1
