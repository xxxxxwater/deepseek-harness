# dsh-magicpath

A [DeepSeek Harness](https://github.com/deepseek-ai) plugin that puts
[MagicPath](https://chatgpt.com/plugins/magicpath) inside a session.

It registers one model-callable tool, `magicpath`, which runs the official
`magicpath-ai` CLI and returns its JSON payload as structured data. The model can
browse and search projects and components, inspect them, read the live canvas
selection, install components, and drive canvas coding sessions — without
leaving the conversation.

## Design

- **One tool, not thirty.** A single `magicpath` tool takes `{command, args, flags}`
  and forwards them to the CLI. A new `magicpath-ai` release needs no plugin
  change, so the bridge does not rot as the CLI grows.
- **Zero `@deepseek-ai/*` imports.** The plugin registers a raw JSON Schema
  `ToolDefinition` on `ctx.tools`. That is the entry point MCP-origin tools use
  and it is stable across the 0.2.x release line, so there is no peer dependency
  to drift out of sync.
- **No shell.** Arguments are passed as an argv array to `spawn`, never through a
  shell, so model-supplied values cannot be re-interpreted as shell syntax.
- **Safe by construction.** `execute` never throws for a CLI failure: a non-zero
  exit, a timeout, and a cancellation all come back as data the model can read.
- **Secret-aware.** A `MAGICPATH_TOKEN` from the credential store or the
  environment is injected into the child process and redacted from every string
  the tool returns.

## Requirements

| Requirement | Value |
| --- | --- |
| DeepSeek Harness | 0.2.1-alpha.1 (any 0.2.x with a raw-JSON-Schema tool registry) |
| Node.js | ^22.19.0 \|\| >=24.0.0 |
| MagicPath CLI | `magicpath-ai` 2.6.1 (fetched through npx, or installed locally) |
| Network | required on first use, unless `magicpath-ai` is installed locally |

## Install

### Option A — the Harness plugin CLI

```sh
"/Users/christse/Desktop/dsh-0.2.1-alpha.1-dist/DeepSeek Harness.app/Contents/Resources/runtime/cli/bin/dsh" \
  plugin --profile desktop add /Users/christse/Desktop/test/dsh-magicpath
```

An absolute local path is an officially supported install spec: the plugin
manager adds the `link:` dependency, appends `dsh-magicpath` to
`dsh.profile.bundles`, and runs pnpm. This writes to `~/.dsh`, which is outside
a workspace-scoped sandbox — run it from a terminal, or approve the escalation.

### Option B — edit the profile directly

1. In `~/.dsh/profiles/desktop/package.json`:

   ```json
   {
     "dependencies": {
       "dsh-magicpath": "link:/Users/christse/Desktop/test/dsh-magicpath"
     },
     "dsh": {
       "profile": {
         "bundles": ["…existing bundles…", "dsh-magicpath"]
       }
     }
   }
   ```

2. Link it into the profile's module tree:

   ```sh
   ln -s /Users/christse/Desktop/test/dsh-magicpath \
     ~/.dsh/profiles/desktop/node_modules/dsh-magicpath
   ```

A package present in `dependencies` but absent from `dsh.profile.bundles` is
inert — both entries are required.

### Activate

Restart DeepSeek Harness. On boot the profile merges this package's
`cordis.patch.yml`, which inserts one Loader row, and the `magicpath` tool
becomes available.

## Authenticate

Check first:

```
magicpath command="info"
```

If `auth.authenticated` is false, either run the sign-in flow:

```
magicpath command="login"
```

…or store a token. Put `MAGICPATH_TOKEN` in the Harness credential store; the
plugin resolves it through `ctx.credentials.resolve('MAGICPATH_TOKEN')` and falls
back to the process environment. A token is never echoed back to the model.

## Usage

| Task | Call |
| --- | --- |
| Check state and available commands | `magicpath command="info"` |
| Browse projects | `magicpath command="list-projects"` |
| Search components | `magicpath command="search" args=["dashboard"]` |
| Read one component | `magicpath command="inspect" args=["button-primary"]` |
| What the user selected on the canvas | `magicpath command="selection"` |
| Install a component | `magicpath command="add" args=["button-primary"]` |
| Get a shareable URL | `magicpath command="share" args=["button-primary"]` |
| Open a canvas coding session | `magicpath command="code" args=["start"] flags={project:"<id>", dir:"<workdir>", name:"hero", width:1440, height:900}` |
| Submit that session | `magicpath command="code" args=["submit"] flags={dir:"<workdir>", wait:true}` |

Editing rules inside a canvas session: touch only `src/App.tsx`,
`src/index.css`, `src/components/generated/**`, and `assets/**`, then submit.

`view` and `view-component` open the operating system browser and block until it
closes; prefer `share`, which returns a URL instead. Because `view` grabs the
machine's browser, the tool reports itself as not concurrency-safe and the Harness
serializes calls.

The tool returns `{ok, command, argv, exitCode, data, stdout, stderr, error, hint}`.
`data` is the parsed JSON payload (npx banner lines are skipped); `hint` carries
the next action when something needs fixing.

## Configuration

Options go on the inserted Loader row in `~/.dsh/profiles/desktop/cordis.patch.yml`:

```yaml
- insert:
    - id: magicpath
      name: 'dsh-magicpath'
      config:
        cliVersion: '2.6.1'
        npmCache: /tmp/dsh-magicpath-npm-cache
        timeoutMs: 120000
```

| Key | Default | Purpose |
| --- | --- | --- |
| `cliPackage` | `magicpath-ai` | npm package providing the CLI |
| `cliVersion` | `2.6.1` | version pinned for the npx fallback |
| `npmCache` | OS temp dir | writable npm cache for the npx fallback |
| `timeoutMs` | `120000` | per-call default, clamped to 5 s … 10 min |
| `cwd` | Harness cwd | working directory for CLI invocations |
| `token` | — | inline `MAGICPATH_TOKEN`; prefer the credential store |

## Troubleshooting

**`EPERM … Your cache folder contains root-owned files`** — npm's default cache
(`~/.npm/_cacache`) contains root-owned entries, and plain `npx` aborts before the
CLI runs. The plugin already points npx at a private cache directory. If that
directory is unusable, set `config.npmCache` to another writable path.

**`code: NOT_AUTHENTICATED`** — expected on a fresh install. Run
`magicpath command="login"`, or store a token.

**The tool does not appear after install** — check both halves of the wiring:
`dsh-magicpath` must be in `dsh.profile.bundles` *and* resolvable from
`~/.dsh/profiles/desktop/node_modules`. Then restart the application.

**First call is slow (~20 s)** — npx is downloading the CLI. Later calls reuse the
cache. To make every call fast and offline, install the CLI into the plugin
directory once with `npm install magicpath-ai`; the plugin prefers a locally
resolvable copy and only falls back to npx.

## Compatibility notes

- The tool name is the short `magicpath` and the Loader id is `magicpath`, matching
  the convention used by the sibling `dsh-sentinelx` plugin (row id `sentinelx`,
  row name `dsh-sentinelx`). The full naming declaration is in
  `dsh-plugin.naming.json`; `validate-names.mjs` exits 0 for it, with two advisory
  `recommended-prefix` warnings for the intentionally short tool and loader names.
- `isConcurrencySafe` is set but is not part of the 0.2.1-alpha.1 `ToolDefinition`
  contract (it does not appear in `dsh-tools`, `dsh-agent`, or `dsh-agent-loop`).
  Unknown keys are ignored by the registry, so it is harmless either way.
- All presentation helpers (`presentCall`, `output.render`) are pure — no I/O,
  clock, or randomness — because the Harness also replays them from the session log.

## Uninstall

```sh
"/Users/christse/Desktop/dsh-0.2.1-alpha.1-dist/DeepSeek Harness.app/Contents/Resources/runtime/cli/bin/dsh" \
  plugin --profile desktop remove dsh-magicpath
```

Or delete the `dsh-magicpath` entry from `dsh.profile.bundles` and the `link:`
dependency, remove the `node_modules` symlink, and restart.

## Development

```sh
cd /Users/christse/Desktop/test/dsh-magicpath
npm test                 # 19 unit tests, no network
node scripts/smoke.mjs   # live end-to-end call through the real CLI
```

| File | Role |
| --- | --- |
| `lib/index.js` | plugin entry: tool definition, canonical value, rendering, hints |
| `lib/cli.js` | argv construction, CLI resolution, spawn, JSON extraction |
| `test/cli.test.mjs` | unit tests for both modules |
| `scripts/smoke.mjs` | end-to-end check against the live CLI |
| `cordis.patch.yml` | the Loader row this bundle inserts |
